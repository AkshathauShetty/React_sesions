import { useRef } from "react"
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

const Formvalidation=()=>{

    const name=useRef("none")
    const email= useRef("none")
    const phone = useRef(0)

    

    const validateForm=(e)=>{
        console.log("event",e)
        console.log("name",name,"email",email,"phone",phone)
        
        let names = e.target.name
        let values = e.target.value

        if(names=="name"){
            if(values==""){
                console.log(values)
                name.current.value="name can't be empty!";
            }
        }
        else if(names=="email"){
            if(values==''){
                console.log(values)
                email.current.value="email can't be empty!";
            }
        }
        else{

            if(values=='' ){
                console.log(values)
                phone.current.value="0000";
            }
        }

    }

    const submit=()=>{
        if(name.current.value=="name can't be empty!" || email.current.value=="email can't be empty!" || phone.current.value=="0000"){
            alert("please enter valid details")
        }
        else{
            alert("form submitted successfully!")
        }
    }

    const styles={
        "backgroundColor":"pink",
        "border":"2px solid black",
        "borderRadius":"10px",
       
    }

    return(
        <div>
            
            <Form style={styles}>

                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                    <Form.Label>Enter name</Form.Label>
                    <Form.Control
                    required
                    name="name"
                    ref={name}
                    value={name.current.value}
                    type="text" placeholder="name"
                    onBlur={validateForm} />
                </Form.Group>

                <Form.Group className="mb-3" controlId="exampleForm.ControlInput2">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control 
                    required
                    name="email"
                    ref={email}
                    value={name.current.value}
                     type="email" placeholder="name@example.com"
                     onBlur={validateForm}  />
                </Form.Group>

                <Form.Group className="mb-3" controlId="exampleForm.ControlInput3">
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                    required
                    name="phone"
                    ref={phone}
                    value={name.current.value}
                    type="password" placeholder="enter your password"
                    onBlur={validateForm}  />
                </Form.Group>

                <Button variant="primary" onClick={submit} style={{textAlign:"center",fontFamily:"serif",fontStyle:"italic"}}>Submit</Button>
                {
                    console.log("name",name,email,phone)
                }
                {console.log("render!")}

            </Form>
        </div>
    )

}


export default Formvalidation
