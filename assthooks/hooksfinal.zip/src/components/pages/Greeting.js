
const Greeting =(props)=>{
    return(
        <div>
            <h2>Functionl component </h2>
            <p>Hello {props.name}, welcome to JS</p>
            <p>Happy learning! </p>
        </div>
    )
}

export default Greeting